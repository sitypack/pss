<?php   
	$dbl_servername = "";
	$dbl_username = "";
	$dbl_password = "";
	


try {
	$spse_telemetrie = new PDO("mysql:host=$dbl_servername;dbname=spse_telemetrie", $dbl_username, $dbl_password);
} catch(PDOException $e) {
	die("The Connection to the database is not available.");
}	 


function get_data()
{
	global $spse_telemetrie;
		
	$stmt = $spse_telemetrie->prepare("SELECT * FROM gps ORDER BY time desc LIMIT 50");
	$stmt->execute();
	$result = $stmt->fetchAll();


	return $result;
}

?>